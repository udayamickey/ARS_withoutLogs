package com.capgemini.ars.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidatorTest {

	@Test
	public void testIsValidCustomerName() {
		assertTrue(new Validator().isValidUserName("Udaya Lakshmi"));
	}
	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new Validator().isValidUserName("Udaya Lakshmi jmksdkmk"));
	}
	
	@Test
	public void testIsValidCustomerEmail() {
		assertTrue(new Validator().isValidCustomerEmail("Udaya.Lakshmi@gmail.com"));
	}
	@Test
	public void testIsNotValidCustomerEmail() {
		assertFalse(new Validator().isValidCustomerEmail("Udaya.Lakshmi@gmail@com"));
	}
	@Test
	public void testIsValidCustomerMobile() {
		assertTrue(new Validator().isValidCustomerMobile(9865328745L));
	}
	@Test
	public void testIsNotValidCustomerMobile() {
		assertFalse(new Validator().isValidCustomerMobile(21099712156526326L));
	}
	@Test
	public void testIsValidCardNumber() {
		assertTrue(new Validator().isValidCardNumber("9865328745253157"));
	}
	@Test
	public void testIsNotValidCardNumber() {
		assertFalse(new Validator().isValidCardNumber("21099716"));
	}

}
