package com.capgemini.ars.service;

import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.ARSException;

public interface IUserService {
	public abstract void addUserDetails(UserBean user)throws ARSException;
	public abstract UserBean getUserDetails(String username)throws ARSException;
	public abstract boolean isValidUser(String username,String password) throws ARSException;
	public abstract String getUserRole(String username,String password)throws ARSException;
}
