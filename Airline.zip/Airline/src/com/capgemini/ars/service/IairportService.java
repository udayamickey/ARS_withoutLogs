package com.capgemini.ars.service;

import java.util.List;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.exception.ARSException;

public interface IairportService {
	public abstract List<AirportBean> getAirportNames() throws ARSException; 
	public abstract Integer addAirport(AirportBean airport)throws ARSException;

}
