package com.capgemini.ars.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.service.AirportServiceImpl;
import com.capgemini.ars.service.BookingServiceImpl;
import com.capgemini.ars.service.FlightserviceImpl;
import com.capgemini.ars.service.IBookingservice;
import com.capgemini.ars.service.IFlightservice;
import com.capgemini.ars.service.IUserService;
import com.capgemini.ars.service.IairportService;
import com.capgemini.ars.service.UserServiceImpl;
import com.capgemini.ars.service.Validator;

public class ARSTester {

	public static IBookingservice bookingService = new BookingServiceImpl();
	public static IFlightservice flightService= new FlightserviceImpl();
	public static 	IUserService userService = new UserServiceImpl();
	public static IairportService airportService= new AirportServiceImpl();
	public static  Scanner scanner= new Scanner(System.in);
	public static Validator validator = new Validator();

	public static void main(String[] args) throws ARSException, ParseException {
		while(true){
			System.out.println("*************************************");
			System.out.println();
			System.out.println("AIRLINE RESERVATION SYSTEM");
			System.out.println();
			System.out.println("*************************************");

			System.out.println("1.Register ");
			System.out.println("2.Login ");
			System.out.println("3.Exit ");
			System.out.println();
			System.out.println("Enter your choice");
			try{
				int n= scanner.nextInt();

				switch(n){
				case 1:
					int flag=0;
					while(flag==0){
						
						System.out.println("Enter your username(Username should not contain spaces...use '_' instead)");
						String uname= scanner.next();
						if(validator.isValidUserName(uname)){
						System.out.println("Create your password");
						String pwd= scanner.next();
						System.out.println("Confirm your password");
						String cpwd= scanner.next();


						if(pwd.equals(cpwd)){
							flag=1;
							System.out.println("Enter your mobile no:");
							Long mobileNo=scanner.nextLong();

							UserBean user = new UserBean(uname,pwd,mobileNo,"USER");
							userService.addUserDetails(user);
							System.out.println("Registered Successfully.....");
							System.out.println("Please Login now...");

						}else{

							System.err.print("your passwords don't match");


						}
						}else{
						System.err.print("Your username should contain only 16 alphabets and Start with capital letter..");
					}
					}

					break;
				case 2: System.out.println("Please Login Here....");
				System.out.println("Enter your username:");
				String uname =  scanner.next();
				System.out.println("Enter password:");
				String password = scanner.next();
				if(userService.getUserRole(uname, password).equalsIgnoreCase("USER")){
					UserBean user=new UserBean(uname);
					System.out.println("Welcome dear "+user.getUserName()+" to Airline Reservation System");
					System.out.println("1.Book Ticket");
					System.out.println("2.View your booking");
					System.out.println("3.View your booking history");
					System.out.println("4.Update your email.");
					System.out.println("5.Cancel Booking");
					System.out.println("Enter your choice:");
					String classType="";
					Double totalfare1=0.0;
					Double totalfare2=0.0;
					try{
						Integer choice=scanner.nextInt();
					
						switch(choice){
						case 1:
							List<AirportBean> airportList = airportService.getAirportNames();
							Iterator<AirportBean> iterator= airportList.iterator();
							while(iterator.hasNext()){
								System.out.println(iterator.next());
							} 
							System.out.println("Enter departure_city");
							String srcCity=scanner.next();
							System.out.println("Enter destination:");
							String destCity=scanner.next();
							System.out.println("Enter date of journey");
							String doj=scanner.next();
							SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
							java.util.Date date = sdf1.parse(doj);
							java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
							List<FlightBean> flightList=flightService.getFlights(srcCity, destCity, sqlStartDate);
							if(flightList!=null){
							Iterator<FlightBean> flightiterator= flightList.iterator();
							while(flightiterator.hasNext()){
								System.out.println(flightiterator.next());
							} 
							System.out.println("Enter existing flightno from the above list ");
							String flightno = scanner.next();
							if(flightService.isValidFlightNo(srcCity, destCity, sqlStartDate, flightno)){
								System.out.println("Enter your mail Id");
								String custEmail = scanner.next();
								if(validator.isValidCustomerEmail(custEmail)){
								System.out.println("Enter number of seats:");
								Integer noOfPassengers=scanner.nextInt();
								System.out.println("Enter your credit card number:");
								String creditCardInfo=scanner.next();
								if(validator.isValidCardNumber(creditCardInfo)){
								
								for(int i=1;i<=noOfPassengers;i++){
									System.out.println("Select the type of seats:1.FirstClass 2.BussinessSeats");
									System.out.println("Select the above type no");
									try{
										Integer seatType = scanner.nextInt();
										if(seatType==1){
											
											classType="FIRSTCLASS";
											if(flightService.getFirstSeatOccupancy(flightno)>noOfPassengers){
												totalfare1 = flightService.firstClassFare(flightno);
												BookingBean bean1=bookingService.addBookingDetails(custEmail, noOfPassengers, classType, creditCardInfo, srcCity, destCity, totalfare1,flightno);
												flightService.updateFirstClassSeats(flightno, noOfPassengers);
												System.out.println("Your booking Id: "+bean1.getBookingId());
												//System.out.println("Your Seat Number: "+bean1.getSeatNo()+" of class type "+classType);
												//System.out.println("Your total fare: "+bean1.getTotalFare());
											
											
											}
										}
										else if(seatType==2){
											classType="BUSSCLASS";
											if(flightService.getBussSeatOccupancy(flightno)>noOfPassengers){
											totalfare2= flightService.bussClassFare(flightno);
											BookingBean bean2 =bookingService.addBookingDetails(custEmail, noOfPassengers, classType, creditCardInfo, srcCity, destCity, totalfare2,flightno);
											 flightService.updateBussClassSeats(flightno, noOfPassengers);
											 System.out.println("Your booking Id: "+bean2.getBookingId());
												//System.out.println("Your Seat Number: "+bean2.getSeatNo()+" of class type "+classType);
												//System.out.println("Your total fare: "+bean2.getTotalFare());
												
											 
											}
										}else{
											System.out.println("Please enter valid class type[1 or 2]..");
										}
									}catch(InputMismatchException e){
										throw new ARSException("Your choice should be integer");
									}
									
							
								
								
									
								}
								}else{
									throw new ARSException("Your credit card number is invalid....");
								}
							}else{
								System.err.print("Please enter valid mailId");
							}
							}else{
								System.err.print("Please enter the flight number from the above specified list..");
							}



							}else{
								System.err.print("Sorry!! No flights matching your required specifications...");
							}




							break;
						case 2:
							System.out.println("Enter your booking id:");
							Integer book=scanner.nextInt();
							
							if(bookingService.getBookingIdList(book)){
								List<BookingBean> beanList=bookingService.viewYourBooking(book);
								Iterator<BookingBean> iterator1= beanList.iterator();
								while(iterator1.hasNext()){
									System.out.println(iterator1.next());
								} 
								}else{
									System.out.println("No bookings with "+book+" Id");
								}
								
							
							break;

						case 3:System.out.println("Enter your email to know your booking history");
						String userMail= scanner.next();
						if(flightService.isValidEmail(userMail)){
						List<BookingBean> beanList=bookingService.getBookingDetails(userMail);
						Iterator<BookingBean> iterator1= beanList.iterator();
						while(iterator1.hasNext()){
							System.out.println(iterator1.next());
						} 
						}else{
							System.out.println("No bookings with "+userMail);
						}

						break;

						case 4:System.out.println("To update your email please enter your booking id:");
						Integer bId = scanner.nextInt();
						if(bookingService.getBookingIdList(bId)){
						System.out.println("Please enter your new mailId");
						String mailId=scanner.next();
						if(validator.isValidCustomerEmail(mailId)){
						Integer update=bookingService.updateEmail(mailId, bId);
						if(update!=0){
							System.out.println("Hey you successfully updated your mailId..");
						}}else{
							
							
							System.out.println("enter valid mailId");
						}
						}else{
							System.out.println("Please Check...No bookings with this booking Id...");
						}
						break;
						
						case 5:System.out.println("Enter the bookingId to cancel your ticket:");
						Integer Bid=scanner.nextInt();
						if(bookingService.getBookingIdList(Bid)){
						String msg=bookingService.deleteBookingDetails(Bid);
						System.out.println(msg);
						}else{
							System.out.println("Please Check..No bookings with this bookingId");
						}
						}

					}catch(InputMismatchException e){
						e.printStackTrace();
					}
				}
				
				else if(userService.getUserRole(uname, password).equalsIgnoreCase("ADMIN")){
					
					UserBean user=new UserBean(uname);
					System.out.println("Welcome dear "+user.getUserName()+" to Airline Reservation System");
					System.out.println("1.Add Flight");
					System.out.println("2.Update Flight Schedule");
					System.out.println("3.Cancel Flight");
					System.out.println("4.Display Flight Details ");
					System.out.println("5.Add airport ");
					System.out.println("6.View Airports");
					System.out.println("7.View Booking Details");
					System.out.println("8.View passenger list of specific flight");
					System.out.println("Enter your choice:");
					int ch=scanner.nextInt();
					switch(ch){
					case 1:
						System.out.println("Enter flightno:");
						String flightno=scanner.next();
						
						System.out.println("enter airline");
						String airline=scanner.next();
						
						System.out.println("enter departure city");
						String depcity=scanner.next();
						
						System.out.println("enter arrival city");
						String arrcity=scanner.next();
						
						System.out.println("enter departure date");
						String depdate=scanner.next();
						SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
						java.util.Date date1 = sdf1.parse(depdate);
						java.sql.Date sqlStartDate1 = new java.sql.Date(date1.getTime()); 
						
						
						System.out.println("enter arrival date");
						String arrdate=scanner.next();
						SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
						java.util.Date date2 = sdf2.parse(arrdate);
						java.sql.Date sqlStartDate2 = new java.sql.Date(date2.getTime()); 
						
						System.out.println("enter departure time");
						String deptime=scanner.next();
						
						System.out.println("enter arrival time");
						String arrtime=scanner.next();
						
						//System.out.println("enter no. of first class seats");
						Integer fseats=120;
						
						System.out.println("enter first seat fare");
						Double ffare=scanner.nextDouble();
						
						//System.out.println("enter no. of bussiness class seats");
						Integer bseats=120;
						
						
						System.out.println("enter bussiness seats fare");
						Double bfare=scanner.nextDouble();
						
						FlightBean flightBean=new FlightBean(flightno,airline,depcity,arrcity,sqlStartDate1,sqlStartDate2,
								deptime,arrtime,fseats,ffare,bseats,bfare);
						
						
						
						flightService.addFlight(flightBean);
						System.out.println("Flight added successfully...");
						
						
						break;
						
					case 2:System.out.println("Enter flightno to update schedule");
					String fno = scanner.next();
					System.out.println("Enter departure time:");
					String dtime = scanner.next();
					System.out.println("Enter arrival time");
					String atime=scanner.next();
					
					Integer uf =flightService.updateFlight(fno,dtime,atime);
					if(uf!=0){
					System.out.println("Updated successfully");
					}
					break;
					case 3:System.out.println("Enter flight no you want to remove:");
					String flight=scanner.next();
					if(flightService.validFlight(flight)){
					Integer upD=flightService.deleteFlight(flight);
					if(upD!=0){
						System.out.println("Deleted...");
					}
					}else{
						System.out.println("Please enter the existing flight number");
					}
					break;
					case 4:
						List<FlightBean> airportList =flightService.getAllFlightDetails();
						if(airportList!=null){
						Iterator<FlightBean> iterator= airportList.iterator();
						while(iterator.hasNext()){
							System.out.println(iterator.next());
						} 
						}else{
							System.out.println("No flight details to display..");
						}
						
						break;
					case 5:
						System.out.println("Enter Airport Details:");
						System.out.println("Enter Airport name:");
						String aname=scanner.next();
						System.out.println("Enter Abbrevation");
						String abb=scanner.next();
						System.out.println("Enter Location");
						String loc=scanner.next();
						AirportBean airport=new AirportBean(aname,abb,loc);
						Integer aAdd=airportService.addAirport(airport);
						if(aAdd!=0){
							System.out.println("Airport Added");
						}
						break;
					case 6:
						System.out.println("Airport Details");
						List<AirportBean> airportList1 = airportService.getAirportNames();
						if(airportList1!=null){
						Iterator<AirportBean> iterator2= airportList1.iterator();
						while(iterator2.hasNext()){
							System.out.println(iterator2.next());
						} 
						}else{
							System.out.println("No airport details to display...");
						}
						
						break;
					case 7:
						System.out.println("Booking Details:");
						List<BookingBean> List1 = bookingService.retrieveAllBookingDetails();
						if(List1!=null){
						Iterator<BookingBean> iterator3= List1.iterator();
						while(iterator3.hasNext()){
							System.out.println(iterator3.next());
						}}else{
							System.out.println("Not yet booked..");
						}
						break;
					case 8:
						System.out.println("Enter flightno to view passenger list:");
						String f=scanner.next();
						if(flightService.validFlight(f)){
						List<BookingBean> List2 = bookingService.viewPassengerList(f);
						if(List2!=null){
						Iterator<BookingBean> iterator4= List2.iterator();
						while(iterator4.hasNext()){
							System.out.println(iterator4.next());
						}
						}else{
							System.out.println("There are no passengers opting this flight..");
						}
						break;
					
					}else{
						System.out.println("Please enter existing flight number..");
					}
					}
				}
				else if(userService.getUserRole(uname, password).equalsIgnoreCase("EXECUTIVE")){
					UserBean user=new UserBean(uname);
					System.out.println("Welcome dear "+user.getUserName()+" to Airline Reservation System");
					System.out.println("1.Occupancy from a given flight on a day.");
					System.out.println("2.Overall Occupancy from all flights "
							+ "flying from a particular source to a particular destination.");
					int ch=scanner.nextInt();
					switch(ch){
					case 1:System.out.println("Enter the given period:");
					System.out.println("Enter date:");
					String sDate = scanner.next(); 
					SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
					java.util.Date date2 = sdf2.parse(sDate);
					java.sql.Date sqlStartDate2 = new java.sql.Date(date2.getTime()); 
					
					
					
					System.out.println("Enter flight number:");
					String Fn=scanner.next();
					if(flightService.validFlight(Fn)){
					List<Integer> list=flightService.occupancyDate(Fn, sqlStartDate2);
					if(list!=null){
					Iterator<Integer> iterator4= list.iterator();
					System.out.println("Occupied First Class seats and Bussiness Class seats for given flight are: ");
					while(iterator4.hasNext()){
						System.out.println(iterator4.next());
					}
					}else{
						System.out.println("Sorry!! No details found..");
					}
					}else{
						System.out.println("Please check for the  valid flight number...");
					}
					break;
					
					case 2:System.out.println("Enter departure city:");
					String depCity=scanner.next();
					System.out.println("Enter arrival city");
					String arrCity = scanner.next();
					List<String> list1=flightService.occupancyCity(depCity, arrCity);
					if(list1!=null){
					Iterator<String> iterator5= list1.iterator();
					System.out.println("FirstClassSeats and Business Class seats and respective flightno:");
					while(iterator5.hasNext()){
						System.out.println(iterator5.next());
					}
					}else{
						System.out.println("Sorry!! No details matching your specifications...");
					}
					break;
					}
					}else{
						System.out.println("User roles should be only USER , ADMIN and EXECUTIVE ");
					}
					
					
				}
				}





			catch(InputMismatchException e){
				throw new ARSException("Only Integers allowed");

			}







		}


	}

}
